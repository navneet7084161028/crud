<?php
require "model.php";
$user = new register();

if(isset($_POST['email'])){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$number = $_POST['number'];
	$address = $_POST['address'];
	$degree = $_POST['degree'];

	$data = $user->insertion($name,$email,$number,$address,$degree);
		if($data == 0){
			echo "1";
		}
		else if($data == 1)
		{
			echo "2";
		}
	}

//delete data from table..... 
if(isset($_POST['id'])){
	$id = $_POST['id'];	
	$data = $user->delete_data($id);
		if($data == 0){
			echo '1';
		}
		else if($data == 1)
		{
			echo '2';
		}
	}

//update data of table
if(isset($_POST['rid'])){
	
	$rid = $_POST['rid'];
	$name = $_POST['name'];
	$email = $_POST['uemail'];
	$number = $_POST['number'];
	$address = $_POST['address'];
	$degree = $_POST['degree'];
	$data = $user->update_Data($rid,$name,$email,$number,$address,$degree);
	if($data == 0){
		echo '1';
	}
	else if($data == 1)
	{
		echo '2';
	}

}
?>