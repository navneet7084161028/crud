<?php 
require "model.php"; 

$rid = $_GET['rid'];
 $conn = new register();
 $data = $conn->edit_Data($rid);

foreach($data as $key => $value){
  foreach($value as $key => $value1){
    // echo $value1;
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Data</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
  <style type="text/css">
    form{
      margin: auto;
      width: 60%;
    }
    span{
      color: red;
    }
    h1{
      text-align: center;
    }
  </style>
</head>
<body>
  <h1>Edit Your Data</h1>
<form>
  <div class="form-group">
    <input type="number" class="form-control" name="rid" id="rid" value="<?php echo $value['id']; ?>" hidden>    
  </div>

  <div class="form-group">
    <label>Full-Name<span> *</span></label><br>
    <input type="text" class="form-control" name="name" id="name" value="<?php echo $value['name']; ?>">    
  </div>

  <div class="form-group">
    <label>Email-Address<span> *</span></label><br>
    <input type="text" class="form-control" name="email" id="email" value="<?php echo $value['email']; ?>">    
  </div>

  <div class="form-group">
    <label>Address<span> *</span></label><br>
    <input type="text" class="form-control" name="address" id="address" value="<?php echo $value['address']; ?>">    
  </div>

  <div class="form-group">
    <label>Mobile-Number<span>*</span></label><br>
    <input type="text" class="form-control" name="number" id="number" value="<?php echo $value['number']; ?>">    
  </div>

  <div class="form-group">
    <label>Qualification<span>*</span></label><br>
    <input type="text" class="form-control" name="degree" id="degree" value="<?php echo $value['degree']; ?>">    
  </div>
  <input type="button" id="update" class="form-control btn-warning" value="Update">
</form>
</body>
</html>
<script>
  $(document).ready(function(){
    $('#update').on('click',function(e){
        var rid = $('#rid').val();
        var name = $('#name').val();
        var email = $('#email').val();
        var number = $('#number').val();
        var address = $('#address').val();
        var degree = $('#degree').val();
        e.preventDefault();
        $.ajax({
          method:'POST',
          url:'control.php',
          data:{
            'rid':rid,
            'name':name,
            'uemail':email,
            'number':number,
            'address':address,
            'degree':degree
          },
          success:function(data){
            console.log(data);
            if(data == 1){
              alert('error in updation');
            }else if(data == 2){
              alert('data updated successfull');
              window.location.href="view.php";
            }
          },
        });
    });
  });
</script>