<!DOCTYPE html>
<html>
<head>
	<title>Crud operation</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
		}
		body{
			background-image: url('https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MXx8Y29sbGVnZXxlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&w=1000&q=80');
			background-repeat: no-repeat;
			background-size: cover;
			background-position: center;
		}
		form{
			margin: auto;
			width: 60%;
		}
		span{
			color: red;
		}
		h1{
			text-align: center;
		}
		#demo{
			margin: auto;
			width: 60%;
			height: 90vh;
			background-color: #88976d;
			opacity: .8;
			margin-top: 3%;
			border-radius: 3%;
		}
		label{
			color: black;
			font-weight: bolder;
		}
	</style>
</head>
<body>
<div id="demo">
	<h1>Registration - Form</h1>
<form>
	<div class="form-group">
		<label>Full-Name<span> *</span></label><br>
		<input type="text" class="form-control" name="name" id="name">		
	</div>

	<div class="form-group">
		<label>Email-Address<span> *</span></label><br>
		<input type="text" class="form-control" name="email" id="email">		
	</div>

	<div class="form-group">
		<label>Address<span> *</span></label><br>
		<input type="text" class="form-control" name="address" id="address">		
	</div>

	<div class="form-group">
		<label>Mobile-Number<span>*</span></label><br>
		<input type="text" class="form-control" name="number" id="number">		
	</div>

	<div class="form-group">
		<label>Qualification<span>*</span></label><br>
		<input type="text" class="form-control" name="degree" id="degree">		
	</div>
	<input type="button" name="btn" id="btn" class="form-control btn-warning" value="Register">
</form>
</body>
</div>
</html>
<script>
	$('document').ready(function(){
		$('#btn').on('click',function(e){
			e.preventDefault();
			let name = $('#name').val();
			let email = $('#email').val();
			let address = $('#address').val();
			let number = $('#number').val();
			let degree = $('#degree').val();
			if(name=="" || email=="" || address=="" || number=="" ||degree==""){
				alert('all fields are required');
			}else{
			$.ajax({
				method:'POST',
				url:'control.php',
				data:{
					'name':name,
					'email':email,
					'address':address,
					'number':number,
					'degree':degree
				},
				success:function(data){
					console.log(data);
					if(data == 1){
						alert("error occured");
					}else if(data == 2){
						alert('success your data has been submitted');
						window.location.href="view.php";
					}
				}
			});
		}
	});
});
</script>