<?php require "model.php"; ?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<title>Display Data</title>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
		}
		body{
			background-color: teal;
		}
		h1{
			text-align: center;
			color: white;
		}
	</style>
</head>
<body>
	<h1>Registration-Form Details</h1>
<div class="container-fluid">
	<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Number</th>
      <th scope="col">Address</th>
      <th scope="col">Degree</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  	<?php 
  		$conn = new register();
  		$data =$conn->display_data();
      // print_r($data);die;
  		foreach($data as $key => $value){
        echo "<tr>";
        $id = $value['id'];
  			foreach($value as $key => $value1){
          echo "<td>$value1</td>";
        }
        echo "<td><a href='edit.php?rid=$id' class='btn btn-outline-warning'>Edit</a>
            <button data-id=$id class='btn butt btn-outline-danger'>Delete</button></td>";
        echo "</tr>";
  		}
  	 ?>
  </tbody>
</table>
</div>
</body>
</html>
<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
<script>
$(document).ready(function(){
  $('.butt').on('click',function(e){
    e.preventDefault();
      var id = $(this).data('id');
      var c=confirm("Confirm before deletion");
        if(c==true)
        {
          $.ajax({
            method:'POST',
            url:'control.php',
            data:{
            'id':id
          },
            success:function(data){
              console.log(data);
            if(data == 1)
            {
              alert('error in deletion');
              location.reload();
            }
            else if(data == 2)
            {
              alert('data deletion success');
              window.location.href='view.php';
            }
          },
      });
    }
    else
    {
      window.location.href='view.php';
    }
  });
});
</script>