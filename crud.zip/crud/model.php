<?php
require "dbcon.php";

class register extends Dbcon {
	public $conn;

	public function __construct(){
		$data = new Dbcon();
		$this->conn = $data->connection();
	}

	public function insertion($name,$email,$number,$address,$degree){
		$sql = "INSERT INTO `admission`(`name`, `email`, `number`, `address`, `degree`) 
		VALUES ('$name','$email','$number','$address','$degree')";
		  if($this->conn->query($sql)){
		  	return true;
		  }else{
		  	return false;
		  }
		  
		}

	public function display_Data(){
		$sql = "SELECT * FROM `admission`";
		$data = $this->conn->query($sql);
		if($data->num_rows>0){
			while($row = $data->fetch_assoc()){
				$a[] = $row;
			}return $a;
		}return false;
	}

	public function delete_Data($id){
		$sql = "DELETE FROM `admission` where `id` = '$id' ";
		if($this->conn->query($sql)){
			return true;
		}else{
			return false;
		}
	}

	public function edit_Data($rid){
		$sql = "SELECT * FROM  `admission` where `id` = '$rid' ";
		$data = $this->conn->query($sql);
		if($data->num_rows>0){
			while ($row = $data->fetch_assoc()) {
					$a[] = $row;
			}return $a;
		}return false;
	}

	public function update_Data($rid,$name,$email,$number,$address,$degree){
		$sql = "UPDATE `admission` SET `name`='$name',`email`='$email',`number`='$number',`address`='$address',`degree`='$degree' WHERE `id` = '$rid' ";
		if($this->conn->query($sql)){
			return true;
		}
		else
		{
			return false;
		}
	}

}
?>